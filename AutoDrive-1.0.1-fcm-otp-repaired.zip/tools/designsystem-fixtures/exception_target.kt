fun exceptionFixtureTarget() = Unit

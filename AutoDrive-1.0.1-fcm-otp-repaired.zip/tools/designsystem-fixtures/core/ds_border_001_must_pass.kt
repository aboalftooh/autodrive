val governed = AutoDriveBorder.Thin
